const JSON_HEADERS = {"content-type":"application/json; charset=utf-8","cache-control":"no-store"};
function json(data, status=200){return new Response(JSON.stringify(data),{status,headers:JSON_HEADERS});}
function clean(v,max=500){return String(v??'').trim().slice(0,max)}
function normalizeHotel(row){
  const get=(...keys)=>{for(const k of keys){if(row[k]!==undefined && row[k]!==null && row[k]!=='' ) return row[k]} return null};
  return {
    id:get('id','hotel_id','ID'),
    name:get('name','hotel_name','Hotel','hotel','arabic_name','local_name'),
    destination:get('destination','city','area','location','Destination'),
    stars:get('stars','star_rating','rating','Stars'),
    image:get('image','image_url','photo','photo_url','thumbnail'),
    description:get('description','desc','notes'),
    source:get('source_url','official_url','source')
  };
}
async function readHotels(env, url){
  const q=clean(url.searchParams.get('q'),120).toLowerCase();
  const destination=clean(url.searchParams.get('destination'),120).toLowerCase();
  const limit=Math.min(Math.max(Number(url.searchParams.get('limit')||100),1),500);
  if(!env.DB) { try { const r=await env.ASSETS.fetch(new URL('/hotels-data.json',url)); const d=await r.json(); const rows=[]; for(const [destination,list] of Object.entries(d||{})){ for(const x of (list||[])){ rows.push({id:null,name:x[0],destination,stars:x[1],image:x[2],description:x[3],source:null}); } } let hotels=rows; if(destination) hotels=hotels.filter(x=>`${x.destination||''}`.toLowerCase().includes(destination)); if(q) hotels=hotels.filter(x=>`${x.name||''} ${x.destination||''} ${x.description||''}`.toLowerCase().includes(q)); return {source:'static',count:hotels.length,hotels:hotels.slice(0,limit)}; } catch(e) { return {source:'static',hotels:[],error:'Static hotel data is not readable'}; } }
  try{
    const r=await env.DB.prepare('SELECT * FROM hotels LIMIT ?').bind(limit).all();
    let hotels=(r.results||[]).map(normalizeHotel).filter(x=>x.name);
    if(destination) hotels=hotels.filter(x=>`${x.destination||''}`.toLowerCase().includes(destination));
    if(q) hotels=hotels.filter(x=>`${x.name||''} ${x.destination||''} ${x.description||''}`.toLowerCase().includes(q));
    return {source:'d1',count:hotels.length,hotels};
  }catch(e){return {source:'fallback',count:0,hotels:[],error:'D1 hotels table is not readable yet'}}
}
async function createLead(env,data){
  if(!env.DB) return {mode:'setup',message:'D1 is not bound to this Worker yet.'};
  try{
    await env.DB.prepare(`CREATE TABLE IF NOT EXISTS leads (id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT, service_type TEXT, destination TEXT, travel_date TEXT, travellers INTEGER, phone TEXT, notes TEXT, stage TEXT DEFAULT 'new', created_at TEXT DEFAULT CURRENT_TIMESTAMP)`).run();
    const r=await env.DB.prepare(`INSERT INTO leads(source,service_type,destination,travel_date,travellers,phone,notes) VALUES(?,?,?,?,?,?,?)`).bind('website',clean(data.service_type||'trip_request',80),clean(data.destination,150),clean(data.travelDate,30),Number(data.travellers||0)||0,clean(data.phone,60),clean(data.notes,1500)).run();
    return {mode:'saved',reference:`JSM-${String(r.meta?.last_row_id||Date.now()).padStart(6,'0')}`};
  }catch(e){return {mode:'error',message:'Could not save the request to D1.'};}
}
export default {async fetch(request,env){
  const url=new URL(request.url); const path=url.pathname;
  if(path==='/api/health') return json({ok:true,service:'JSM TRAVEL Worker',d1:!!env.DB,time:new Date().toISOString()});
  if(path==='/api/hotels' && request.method==='GET') return json(await readHotels(env,url));
  if(path==='/api/destinations' && request.method==='GET'){
    const r=await readHotels(env,new URL('https://x/api/hotels?limit=500'));
    const set=[...new Set(r.hotels.map(x=>x.destination).filter(Boolean))]; return json({source:r.source,destinations:set});
  }
  if(path==='/api/trip-request' && request.method==='POST'){
    let data={}; try{data=await request.json()}catch{return json({mode:'error',message:'Invalid JSON'},400)}
    if(!data.destination||!data.phone) return json({mode:'error',message:'Destination and phone are required.'},400);
    return json(await createLead(env,data));
  }
  if(path==='/api/hotel-search' && request.method==='POST'){
    let data={}; try{data=await request.json()}catch{return json({mode:'error',message:'Invalid JSON'},400)}
    const u=new URL('https://x/api/hotels'); if(data.cityCode) u.searchParams.set('q',data.cityCode); u.searchParams.set('limit','50');
    const result=await readHotels(env,u);
    return json({mode:result.source==='d1'?'local':'setup',results:result.hotels,message:result.source==='d1'?'Local JSM hotel database results.':'Live worldwide hotel pricing requires a connected supplier.'});
  }
  if(path==='/api/flight-search' && request.method==='POST') return json({mode:'setup',results:[],message:'Live flight search requires a connected flight supplier/API. No fake prices are shown.'});
  if(path.startsWith('/api/')) return json({error:'Not found'},404);
  return env.ASSETS.fetch(request);
}};
